function concatenarDados() {
    // Obter os valores dos campos do formulário
    const nome = document.getElementById('nome').value;
    const estadoCivil = document.getElementById('estadoCivil').value;
    const faixaEtaria = document.getElementById('faixaEtaria').value;

    // Concatenar os valores em uma única string
    const resultado = `Nome: ${nome}, Estado Civil: ${estadoCivil}, Faixa Etária: ${faixaEtaria}`;

    // Exibir o resultado em um alerta (você pode modificar isso conforme necessário)
    alert(resultado);
}
