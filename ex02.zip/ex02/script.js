function verificarFormulario() {
    var login = document.getElementById('login').value;
    var senha = document.getElementById('senha').value;
    if (login === '' || senha === '') {
      alert('Por favor, preencha todos os campos.');
      return false;
    }
    return true;
  }