function calcularIMC() {
    // Obtém os valores de peso e altura do formulário
    const peso = parseFloat(document.getElementById("peso").value);
    const altura = parseFloat(document.getElementById("altura").value);
  
    // Verifica se os valores são válidos
    if (isNaN(peso) || isNaN(altura) || peso <= 0 || altura <= 0) {
      alert("Por favor, insira valores válidos para peso e altura.");
      return;
    }
  
    // Calcula o IMC
    const imc = peso / (altura * altura);
  
    // Determina a classe do IMC
    let classeIMC;
    if (imc < 16.9) {
      classeIMC = "Muito abaixo do peso";
    } else if (imc >= 17 && imc <= 18.4) {
      classeIMC = "Abaixo do peso";
    } else if (imc >= 18.5 && imc <= 24.9) {
      classeIMC = "Peso normal";
    } else if (imc >= 25 && imc <= 29.9) {
      classeIMC = "Acima do peso";
    } else {
      classeIMC = "Obesidade";
    }
  
    // Exibe o resultado
    const resultado = `Seu IMC é ${imc.toFixed(2)} - ${classeIMC}`;
    document.getElementById("resultado").textContent = resultado;
  }
  